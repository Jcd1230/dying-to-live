bin/luajit ../lua/boot.lua
