local ffi = require("ffi")
return ffi.load("./libsoil.so")