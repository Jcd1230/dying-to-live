local ffi = require("ffi")
return ffi.load("SDL2")