
##Exporting from blender

Export with:

* Right-handed
* Export Meshes/Normals/UV
* Normals must **not** be flipped
