local class = require("30log")
local ffi = require("ffi")

local _M = {}

local assetsDir = "../assets/"

local textureBank = {}

function _M.getModel(assetPath)

end

return _M