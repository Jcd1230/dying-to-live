local class = require("30log")
local ffi = require("ffi")

local _M = class("Entity")

function _M:init()
	
end


return _M