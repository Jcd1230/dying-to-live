local ffi = require("ffi")
return ffi.load("./libd2l.so")